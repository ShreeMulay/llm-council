# USER.md - About Your Human

## The Basics

- **Name:** Dr. Shree Mulay
- **DOB:** November 26, 1980
- **What to call them:** Shree
- **Pronouns:** he/him
- **Timezone:** America/Chicago (Central Time)
- **Email:** shree.mulay@thekidneyexperts.com
- **GitHub:** ShreeMulay

## Family

- **Wife:** Anna Lee-Mulay, MD (DOB: September 26, 1980) — Board-certified Internal Medicine, Co-Founder of TKE
- **Daughter:** Adalyn "Adi" Mulay (DOB: September 27, 2020)
- **In-laws:** Haderbouji (father-in-law), Haalmoni (mother-in-law) — Korean terms of endearment
- **Father:** Ramakant Mulay, MD — was a nephrologist in Dyersburg, TN (legacy practice)
- **Location:** Jackson, TN (moved from Dyersburg for better environment for Adi)

## Professional Context

- **Title:** Co-Founder / Chairman / CEO (Chief Empathy Officer) / Nephrologist
- **Organization:** The Kidney Experts, PLLC (TKE)
- **Ownership:** Salsabeel, Inc. (50% Shree, 50% Anna) owns 100% of TKE
- **Joint Venture:** Salsabeel owns 49% of Premier Dialysis Arlington (home dialysis JV)
- **Not board-certified** in nephrology or internal medicine
- **Founded:** September 4, 2018 (first day seeing patients)
- **Mission:** "We transform kidney health by preventing the need for dialysis, prioritizing transplants and home therapies, and empowering patients through education."
- **BHAG:** "Ridding the World of the Need for Dialysis!"
- **Patient Tagline:** "Big Expertise. Small-Town Heart."
- **Internal Tagline:** "Treated like family. Built for impact."
- **Vision:** The "Starbucks of Kidney Care" — standardized excellence that scales to 100+ locations

### Practice Details

- **Team:** 2 nephrologists (Shree + Anna), 5 APPs (4 NPs, 1 PA), virtual scribes
- **Patients:** ~3,700 CKD patients
- **Locations:** Jackson (primary), Dyersburg, Union City (1x/week), Covington (1-2x/month)
- **Hospital:** Jackson Madison County General Hospital (West Tennessee Healthcare)
- **Dialysis:** <25 units across DaVita, Fresenius, DCI, Premier Dialysis
- **Care Model:** Kidney Care First (KCF) / CKCC

### Revenue Trajectory

- 2018-2019: $1M (with income guarantee)
- 2022: $2.03M
- 2023: $2.89M (42% YoY)
- 2024: $3.59M (24% YoY)
- 2025: Projecting $4M (11% YoY)
- 2026 Goal: $5M

### Key Team Members

- **Selena Reyes** — Board of Directors, potential future CEO
- **Rhett Baldeviso** — Director of Revenue Operations
- **Vistage CEO Group:** CE 3864 Memphis, Chair Carey Folk, 13 members

### Clinical Transition Plan

- **Current:** 3-4 days/week clinical across locations
- **Target (2025-2026):** 1-2 days/week clinical, focus shifts to AI development, product building, strategic growth
- **Long-term (2027+):** 1 clinic/week, primary CEO role, national expansion

## Origin Story

Born Framingham MA, grew up Dyersburg TN. Father was a nephrologist — Shree was traumatized by the dialysis-as-cash-flow model. "The last thing I thought I would do: become a doctor, become a nephrologist, come back to TN." Spent 10 years in India for medical school (parents' choice — he wanted IT entrepreneurship). Serial entrepreneur: computer company (high school), indiwave.com (med school), IT classes at BU/Harvard Extension. Met Anna during NYC residency. UW-Madison fellowship for broadest technical exposure. Returned to West TN to transform father's practice into its antithesis. "I've been waiting my entire lifespan for AI to integrate into healthcare."

## Faith (IMPORTANT)

- **Strict Monotheist / Submitter** ("Muslim" in Arabic, but NOT conventional hadith-based Islam)
- Follows **Quran ALONE** — does NOT follow non-Quranic hadith-based Islam (NQHBI)
- Uses ONLY the **Authorized English Version of the Quran (AEVQ)** by Dr. Rashad Khalifa
- Core belief: "Worship God alone without partners"
- Studies ALL world scriptures (Torah, Gospel, Gita, Vedas, Buddhist texts, Sikh scriptures) for underlying universal truth
- This is central to his identity and daily routine — morning briefings include scripture study

## Work Style (PI: Collaborator Profile)

Based on Predictive Index assessment:
- **Low Dominance** — collaborative, not authoritarian
- **High Extraversion** — excellent relationship builder, energized by people
- **High Patience** — steady, patient, prefers stability
- **Low Formality** — flexible with ambiguity, adaptable
- Thrives in collaborative environments
- May avoid conflict to maintain harmony (offset by "Direct is Kind" value)

## Technical Preferences

- **AI Model:** Claude Opus 4.5 ONLY — explicitly stopped using GLM 4.7 (too many errors)
- **Runtime:** Bun over Node.js (always)
- **Frontend:** React 19, Shadcn/ui v4, Tailwind CSS v4
- **Backend:** Bun.serve() for TypeScript, FastAPI for Python
- **State:** Zustand (client), TanStack Query (server)
- **Validation:** Zod
- **Always** keep thinking enabled in AI responses

## Communication Style

- Prefers concise, direct responses — no filler
- No unnecessary praise or sycophancy
- Values technical accuracy over validation
- Appreciates systems thinking
- Says "engage" instead of "execute" to start work
- Says "make it so" when approving a plan
- Data over opinion — "prove it before scaling"

---

The more you know, the better you can help. But remember — you're learning about a person, not building a dossier. Respect the difference.

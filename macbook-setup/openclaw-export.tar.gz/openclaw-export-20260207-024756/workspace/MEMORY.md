# MEMORY.md - Long-Term Memory

*Last updated: 2026-02-05*

## Key Facts About Shree

- Nephrologist, 45 years old, Jackson TN
- Wife Anna (co-nephrologist), Daughter Adi (5 years old)
- Faith: Quran-alone Submitter — uses ONLY AEVQ by Dr. Rashad Khalifa
- Studies all world scriptures for universal truth
- Prefers Claude Opus 4.6 exclusively (stopped GLM 4.7 — too many errors)
- Says "engage" to start, "make it so" to approve
- PI Collaborator profile: collaborative, relationship-builder, patient, flexible
- Vistage CEO Group CE 3864 Memphis, Chair Carey Folk

## Active Projects (as of Feb 2026)

| Project | Status | Location/ID | Notes |
|---------|--------|-------------|-------|
| **Fax Manager v2** | Active (Phase 9) | `~/ai_projects/development/fax-manager-v2` | Google Apps Script, GCP: fax-manager-tke. Nephrology intelligence platform. Council-driven improvements through Phase 8. |
| **RUBE Notification Suite** | Active | Composio recipes | 10 recipes live, 1 planned. Morning Briefing v5.1 is flagship. |
| **CKD Epic Template** | Active | `~/ai_projects/development/ckd-epic-template` (approx) | SmartPhrase modernization for Epic EHR |
| **Clarity Engine** | Active | `~/ai_projects/development/clarity-engine` | Video-to-dashboard processing |
| **TKE Culture v4.0** | Finalized | `~/ai_projects/tke-culture/` | 8 files + Culture Kernel JSON + Master Prompt + AI System Prompt |
| **OpenClaw/Kai Setup** | Active | `~/.openclaw/`, `~/openclaw/` | LLM-Guard security proxy + OpenClaw gateway |
| **Premier Dialysis Chatbot** | Recent | — | Chatbot with citations for Premier Dialysis |
| **LLM Council** | Tool | MCP server | Multi-model deliberation (Opus 4.5, Gemini Flash 3.0, Grok 4.1, GLM 4.7) |
| **AI History RAG** | Tool | `~/ai_projects/development/ai-history-rag/` | Semantic search across all AI conversation history |
| **Adi School App** | Paused | `~/ai_projects/development/adi-school-training-program` | Learning adventure for Adi |
| **Agent Research** | Learning | `~/ai_projects/development/agent-orchestration-research` | LangChain, CrewAI, Agno frameworks |

## RUBE Recipes (Composio)

| # | Recipe | ID | Schedule | Status |
|---|--------|----|----------|--------|
| 1 | Email Triage | rcp_zwBWsr6CYwlm | Every 6 hours | Live v2 |
| 2 | GitHub Dashboard | rcp_N3P6K138M-BC | Weekdays 13:00 UTC | Live v2 |
| 3 | Research Assistant | rcp_LzJ7tKsMR-d7 | On-demand | Tested v1 |
| 4 | Morning Briefing | rcp_1-jIyNGSbOyt | Weekdays 13:00 UTC | Live v5.1 |
| 5 | Weekly Dev Status | rcp_0LSkgWf_yZu9 | Mondays 14:00 UTC | Live v1 |
| 6 | Scripture on Demand | rcp_QFvWkJgtxSO3 | On-demand | Live v1.1 |
| 7 | Mid-day Check-in | rcp_7TqTRuY-SXi5 | Weekdays 18:30 UTC | Live v1.1 |
| 8 | Evening Reflection | rcp_nKDAo2quzUcf | Daily 02:00 UTC | Live v1.0 |
| 9 | Jumu'ah Sermon Generator | rcp_YONNvTPZXeLl | Fridays 12:00 UTC | Live v1.0 |
| 10 | Weekly Verse Digest | rcp_OtVwM0S3cW-Y | Fridays (needs schedule) | Needs verify |
| 11 | Topic Explorer | TBD | On-demand | Planned |

### Scripture Engine Notes

All scripture recipes share a canonical engine:
- AEVQ_COUNTS: 114 suras, 6234 total verses
- Verse selection: daily (day-of-year deterministic), random, or specific (sura:verse)
- Fetches from masjidtucson.org/quran/noframes/ch{N}.html
- Footnotes: masjidtucson.org/quran/noframes/ch{N}fn.html
- Submitter's Perspective: masjidtucson.org/publications/books/sp/ (note: `/publications/` with 's')
- Monotheism Lens: Theological lens + term glossary + A/B/C classification rubric
- Cross-references: Fetches ALL verse refs from footnotes
- Web search: 6 world traditions (Torah, Gospel, Gita, Vedas, Buddhist, Sikh)

## Fax Manager v2 - Key Architecture

- **Runtime:** Google Apps Script (pure JS, NOT TypeScript)
- **GCP Project:** fax-manager-tke
- **Apps Script ID:** 1BQNRB1DgGZ5be-MAllnBzZXGkekjvcXOlu972Hc2FoAkUn6OM-R9F0d2
- **Monitor Email:** email@thekidneyexperts.com
- **Pipeline:** Gmail trigger -> PDF extract -> Gemini 3 Flash multipass -> Intelligence.gs -> Notifications.gs -> Google Chat cards
- **Key files:** Code.gs, Config.gs, Gemini.gs, Intelligence.gs, Notifications.gs, Prompts.gs, Tests.gs
- **48+ tests passing** across 8+ test functions
- **Phase 9** was last worked on (clinical safety improvements)

## TKE Culture v4.0 (Finalized)

- **5 Values:** People First, Prevention Over Profit, Work Smart Not Long, Data Over Opinion, AI Amplifies Human Impact
- **6 Fundamentals:** Direct is Kind, Listen First Then Act, Fix the System Own Your Part, Test Learn Evolve, Unreasonable Hospitality (Precision Hospitality), AI in Everything
- **Decision Filter:** 5 questions before significant decisions
- **Operating Principle:** "What happens to one, happens to all" (Shared Fate)
- **Framework sources:** Coryell (Revolutionize Teamwork), Friedman (Culture by Design), Guidara (Unreasonable Hospitality), Reason (Swiss Cheese Model)
- **Files:** `~/ai_projects/tke-culture/` (8 culture docs), `~/ai_projects/tke-master-prompt/` (Master Prompt + AI System Prompt)

## Technical Decisions & Timeline

| Date | Decision | Notes |
|------|----------|-------|
| 2026-01-22 | Switched from GLM 4.7 to Claude Opus 4.5 only | GLM had too many errors |
| 2026-01-30 | Built RUBE recipe suite (Email Triage through Weekly Dev Status) | Composio platform |
| 2026-01-31 | Built notification suite (Scripture, Mid-day, Evening, Jumu'ah, Weekly) | All deployed |
| 2026-02-01 | Finalized TKE Culture v4.0, built Culture Kernel + Master Prompt | Committed to GitHub |
| 2026-02-03 | Implemented LLM-Guard security layer for OpenClaw | Defense-in-depth |
| 2026-02-04 | Memory migration session: extracted AI history, connected Telegram | Stopped mid-execution |
| 2026-02-05 | Completed memory file migration (this session) | Files written to workspace |
| 2026-02-06 | Upgraded model to Opus 4.6, updated OpenClaw to v2026.2.3-1 | Config updated |
| 2026-02-06 | Full security hardening: removed Inngest (6 exposed ports), killed stray Vite servers | Zero exposed ports now |
| 2026-02-06 | Hardened openclaw.json: DM pairing, guild allowlist, mDNS off, timezone set | Discord-only for now |
| 2026-02-06 | Installed OpenClaw-Shield v0.1.0 (Knostic) | 5-layer accident prevention |
| 2026-02-06 | Decision: Full-auto mode for Kai. Shree is sole user — no adversarial threat | OpenClaw-Shield as seatbelt |
| 2026-02-06 | Decision: Kai will orchestrate OpenCode for project management | coding-agent skill enabled |
| 2026-02-06 | Decision: Skip Lakera Guard, Pangea — overkill for sole-user setup | Revisit if TKE scales AI |

## Lessons Learned

### RUBE/Composio
- Triple-quote docstrings cause SyntaxError in workflow_code (use `# comment` headers instead)
- Gemini 3.0 Flash thinking model returns `parts` with `"thought": true` — must filter these out
- Even short outputs need `maxOutputTokens >= 256` (thought tokens eat the budget)
- RUBE recipe output schemas: avoid nested objects, use simple scalar types
- Submitter's Perspective URL: `/publications/` (with 's'), NOT `/publication/`

### Fax Manager
- `normalizeAiResult()` needed to bridge flat Gemini schema to nested internal schema
- Anemia severity `'unknown'` should be `'none'` to avoid spurious alerts
- Clinical intelligence should be gated — only run on clinical fax types
- Google Chat cardsV2: `#D50000` is too dark for red text, use `#EA4335` (Google Red 500)

### OpenClaw
- `~/.clawdbot` is symlinked to `~/.openclaw` — careful with moves/backups
- Discord resume loop: caused by stale session state, fixed by fresh boot
- LLM-Guard proxy must start before OpenClaw (BindsTo dependency)
- OpenClaw-Shield: installed via `openclaw plugins install https://github.com/knostic/openclaw-shield`
- Shield may break on OpenClaw updates — Knostic warns it may not remain effective for more than a few days after OC updates
- `message:received` hook does NOT exist yet in OpenClaw — cannot intercept inbound Discord/Telegram messages for scanning
- Coding-agent skill: always use `pty:true` for OpenCode/Codex sessions — they need a pseudo-terminal
- Background sessions: use `openclaw gateway wake` at end of prompt for immediate completion notification

### Project Orchestration
- Kai orchestrates via coding-agent skill: spawn OpenCode in target `workdir`, monitor via `process` tool
- Monorepo: `~/ai_projects/` — projects in `development/`, culture in `tke-culture/`, datasets in `datasets/`
- Task tracking: `bd` (Beads) CLI — ALWAYS use for issue tracking, never markdown TODOs
- Project planning: OpenSpec (specs in `openspec/` dirs) — "agree first, build second"
- Factory workflow: `/factory-kickoff` for new projects, `/factory-session-start` for daily work
- Tech defaults: Bun (not Node), React 19, Shadcn/ui v4, Tailwind CSS v4, Zod, Zustand

## Communication Notes

- Shree values being told when something won't work rather than false agreement
- Appreciates systems thinking and root cause analysis
- Prefers parallel execution and batched work
- Likes tables and structured output
- Says "summon the council" when he wants multi-model deliberation

## Discord Context

- **Server:** "Shree's Second Brain" (ID: 1467791371984306208, owner: true, 3 members)
- **Key channels:** #ocean (forum, 30+ threads), #project-threads, #general
- **Notable threads:** Mission Control (114 msgs), Vistage CEO Group (106 msgs), Dr. Adnani Recruitment (71 msgs), Discord Thread Auto-Titling (59 msgs), Inbox Manager (22 msgs), captains-log
- **Full extraction pending** — may use DiscordChatExporter in the future

## TKE Business Context

- **Revenue:** $1M (2019) -> $3.59M (2024) -> $4M projected (2025) -> $5M goal (2026)
- **Team:** 2 nephrologists, 5 APPs, virtual scribes
- **Locations:** Jackson (primary), Dyersburg, Union City, Covington
- **Vision:** 100+ locations in 5 years, "Starbucks of Kidney Care"
- **Strategic frameworks:** "The Science of Scaling" (Hardy), "Teamwork" (Dawson), StoryBrand (Miller)
- **Premier Dialysis JV:** 49% owned, lowest-cost JV in market, home therapy exclusive

---

*This is curated long-term memory. Daily files go in `memory/YYYY-MM-DD.md`. Update this file when significant events, decisions, or learnings occur.*

# Discord Commands

## Thread Commands
- retitle - Auto-generate title from thread content
- retitle: My Title - Set a specific title
- !lock - Lock title + add pin prefix (prevents auto-rename)
- !unlock - Unlock title + remove pin prefix
- !help - Show command list

## Auto-Titling
- On-the-fly when responding in new threads
- Cron sweep every 15 min for ocean forum
- Locked threads (pin prefix) are skipped
- project-threads channel is skipped

## Title Format
- Descriptive, concise (under 100 chars)
- Emoji prefix when appropriate
- Format: Topic - Specific Detail

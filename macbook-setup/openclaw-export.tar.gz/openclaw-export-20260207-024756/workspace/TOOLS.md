# TOOLS.md - Local Notes

## Infrastructure

### Network

- **Tailscale:** `penguin.tail25c91d.ts.net`
- **OS:** Debian 12 (bookworm) in ChromeOS Crostini
- **Python:** 3.12.9 (pyenv)
- **Node.js:** v24.13.0

### Services

| Service | Port | Purpose |
|---------|------|---------|
| `llm-guard-proxy.service` | 8080 | LLM-Guard security proxy — scans all traffic for prompt injection |
| `openclaw-gateway.service` | 18789 | OpenClaw main gateway — BindsTo llm-guard (fail-closed) |

```bash
# Check service status
systemctl --user status openclaw-gateway llm-guard-proxy

# Restart OpenClaw (proxy restarts with it due to dependency)
systemctl --user restart openclaw-gateway

# View logs
journalctl --user -u openclaw-gateway -f
journalctl --user -u llm-guard-proxy -f

# LLM-Guard health check
curl http://127.0.0.1:8080/health

# LLM-Guard scan
curl -X POST http://127.0.0.1:8080/scan -H "Content-Type: application/json" -d '{"text": "content to scan"}'

# LLM-Guard metrics
curl http://127.0.0.1:8080/metrics
```

### Key Directories

| Path | Purpose |
|------|---------|
| `~/openclaw/` | OpenClaw production directory |
| `~/openclaw/security-layer/` | LLM-Guard proxy code + Python venv |
| `~/.openclaw/` | OpenClaw config + workspace |
| `~/.openclaw/workspace/` | Memory files (this directory) |
| `~/.openclaw/openclaw.json` | Main OpenClaw config |
| `~/.bash_secrets` | API keys (ANTHROPIC_API_KEY, etc.) |
| `~/ai_projects/` | All development projects |

### API Keys

Stored in `~/.bash_secrets` (sourced by shell):
- `ANTHROPIC_API_KEY` — Claude API access
- Other keys as needed

### OpenClaw

- **Version:** v2026.2.3-1
- **Model:** anthropic/claude-opus-4-6
- **Gateway token:** Configured in `~/.openclaw/openclaw.json`
- **Canvas:** `http://127.0.0.1:18789/__openclaw__/canvas/`
- **Shield:** Knostic OpenClaw-Shield v0.1.0 (5 layers: prompt-guard, output-scanner, tool-blocker, input-audit, security-gate)

### Security Layers

| Layer | What | Status |
|-------|------|--------|
| LLM-Guard proxy (port 8080) | Scans CLI/API requests for injection, jailbreak, PII, secrets, toxicity | Active |
| OpenClaw-Shield plugin | Blocks destructive commands, scans output for secrets/PII, gates tool execution | Active, enforce mode |
| Discord hardening | Guild allowlist, DM pairing, mDNS off | Configured |
| File permissions | Config 600, workspace 600, secrets 600, settings.py 444 | Locked |
| Network | All services loopback only, zero exposed ports | Clean |

### Coding Agent Integration

Kai can orchestrate OpenCode (and Codex, Claude Code, Pi) via the `coding-agent` skill.

```bash
# Spawn OpenCode on a project (background, with PTY)
bash pty:true workdir:~/ai_projects/development/PROJECT background:true command:"opencode run 'Your task here'"

# Monitor progress
process action:log sessionId:XXX
process action:poll sessionId:XXX

# Send input to the session
process action:submit sessionId:XXX data:"yes"

# Kill if needed
process action:kill sessionId:XXX

# Wake notification when done (add to prompt):
# When completely finished, run: openclaw gateway wake --text "Done: [summary]" --mode now
```

### Beads Issue Tracking (`bd` CLI)

```bash
bd ready              # Find available work
bd show <id>          # View issue details
bd create "title" --description="what and why" -t task -p 1 --json
bd update <id> --status in_progress
bd close <id>
bd sync               # Sync with git
```

Issue types: bug, feature, task, epic, chore
Priorities: 0 (critical) through 4 (backlog)

### Discord Bot

- **Name:** @Kai
- **Bot ID:** 1467786350068629758
- **Server:** Shree's Second Brain (ID: 1467791371984306208)
- **Token:** Configured in `~/.openclaw/openclaw.json` (channels.discord.token)

### Telegram Bot

- **Name:** @kai_tke_bot
- **Bot ID:** 8112719111
- **Shree's User ID:** 8188175032

---

Add whatever helps you do your job. This is your cheat sheet.
